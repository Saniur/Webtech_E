<html>
  <body align=left>
      
<style>
	body {
    font-size: 16px;
    font-family: system-ui;
    background:-webkit-radial-gradient(top left, #4Fbc80,#689AC6);
	font-style:italic;
}

.form{
    width: 100%;
}
h2 {
    text-align: center;
    color: #ef6e58;
}
form {
    width: 300px;
    padding: 15px 40px 40px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #ffffff;
    margin: auto;
}
label {
    display: block;
    margin-bottom: 5px
}
label i {
    color: #999;
    font-size: 80%;
}
input, select {
    border: 1px solid #ccc;
    padding: 10px;
    display: block;
    width: 100%;
    box-sizing: border-box;
    border-radius: 2px;
    background-color: #a9bae64a;
}
.box {
    padding-bottom: 10px;
}
.form-inline {
    border: 1px solid #ccc;
    padding: 8px 10px 4px;
    border-radius: 2px;
}
.form-inline label, .form-inline input {
    display: inline-block;
    width: auto;
    padding-right: 25px;
}
.error {
    color: red;
    font-size: 90%;
}
input[type=text]{
        outline: none;
}

input[type="submit"] {
    font-size: 110%;
    font-weight: 100;
    background: #ef6e58;
    border-color: #ef6e58;
    box-shadow: 0 3px 0 #bd432e;
    color: #fff;
    margin-top: 10px;
    cursor: pointer;
}
input[type="submit"]:hover {
    background: #bd432e;
    border-color: #bd432e;
}

.input-1{
    background-image: url(check.png);
    background-repeat: no-repeat;
    background-position: right 10px center;
    border:1px solid #01cc40;
}
.input-2{
    background-image: url(cancel.png);
    background-repeat: no-repeat;
    background-position: right 10px center;
    border:1px solid red;
}
.input-3{
    border:1px solid #01cc40!important;
}
select{
    outline: none!important;
}
.input-4{
    border:1px solid red;
}
</style> 

</style>	 
      
    <h2>Registration Form</h2>
	<form action="save-form.php" method="post">
    <div class="box">
        <label>Full Name</label>
        <input type="text" name="sname" id="sname" placeholder=" Full name">
       
    </div>
    <div class="box">
        <label>Email Address</label>
        <input type="text" name="email" id="email" placeholder=" Email address">
       
    </div>
    <div class="box">
        <label>Mobile Number</label>
        <input type="text" name="mobile" maxlength="11" id="mobile" placeholder=" Mobile Number">
       
    </div>
    
    <div class="box">
        <label>Gender</label>
        <div class="form-inline" id="gender" placeholder=" Gender">
            <label><input type="radio" name="gender" value="male"> Male</label>
            <label><input type="radio" name="gender" value="female"> Female</label> 
        </div>
        
    </div>
          
    <div class="box">
        <input type="submit" value="Submit">
    </div>
</form>
	   
  </body>
 </html>