<style>
	body {
    font-size: 16px;
    font-family: system-ui;
    background:-webkit-radial-gradient(top left, #f7d4ff,#ffd2d2);
}
</style>
<?php 
 if($_POST['sname'] != '' && $_POST['email'] != '' && $_POST['mobile'] != '' && $_POST['gender'] != ''){
  if(file_exists('json/data.json')){
	  $current_data = file_get_contents('json/data.json');
	  $array_data = json_decode($current_data, true);
	  $new_data = array(
	                
					'sname' => $_POST['sname'],
					'email' => $_POST['email'],
					'mobile' => $_POST['mobile'], 
					'gender' => $_POST['gender']
 
					);
	  $array_data[]=$new_data;
	  $json_data = json_encode( $array_data, JSON_PRETTY_PRINT);
	  
	  if(file_put_contents('json/data.json',$json_data))
	  {
		  echo "<h3>Successfully saved in JSON file.</h3>";
      }else{
		  echo "<h3>Unsuccessfully saved in JSON file.</h3>";
	  }
   }else{
		 echo "<h3>JSON file not exist.</h3>";
    }
  }else{
		  echo "<h3>All form fields are required.</h3>";
   }	
?>	  