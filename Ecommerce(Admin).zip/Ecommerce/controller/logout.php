<?php
	session_start();
	session_destroy();
	 echo '<META HTTP-EQUIV=REFRESH CONTENT="1; admin_login.php">' ;

?>