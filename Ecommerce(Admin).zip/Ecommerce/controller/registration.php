<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
<style>
	body {
    font-size: 16px;
    font-family: system-ui;
    background:-webkit-radial-gradient(top left, #4Fbc80,#689AC6);
	font-style:italic;
}

.form{
    width: 100%;
}
h2 {
    text-align: center;
    color: #ef6e58;
}
form {
    width: 300px;
    padding: 15px 50px 50px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #ffffff;
    margin: auto;
}
label {
    display: block;
    margin-bottom: 5px
}
label i {
    color: #999;
    font-size: 80%;
}
input, select {
    border: 1px solid #ccc;
    padding: 10px;
    display: block;
    width: 100%;
    box-sizing: border-box;
    border-radius: 2px;
    background-color: #a9bae64a;
}
.box {
    padding-bottom: 10px;
}
.form-inline {
    border: 1px solid #ccc;
    padding: 8px 10px 4px;
    border-radius: 2px;
}
.form-inline label, .form-inline input {
    display: inline-block;
    width: auto;
    padding-right: 25px;
}
.error {
    color: red;
    font-size: 90%;
}
input[type=text]{
        outline: none;
}

input[type="submit"] {
    font-size: 110%;
    font-weight: 100;
    background: #ef6e58;
    border-color: #ef6e58;
    box-shadow: 0 3px 0 #bd432e;
    color: #fff;
    margin-top: 10px;
    cursor: pointer;
}
input[type="submit"]:hover {
    background: #bd432e;
    border-color: #bd432e;
}

.input-1{
    background-image: url(check.png);
    background-repeat: no-repeat;
    background-position: right 10px center;
    border:1px solid #01cc40;
}
.input-2{
    background-image: url(cancel.png);
    background-repeat: no-repeat;
    background-position: right 10px center;
    border:1px solid red;
}
.input-3{
    border:1px solid #01cc40!important;
}
select{
    outline: none!important;
}
.input-4{
    border:1px solid red;
}
</style>   
    
</head>
<body>
   
<p><a href="admin_login.php" class="btn btn-warning">Back to Home</a><p>        

<form name="Form" onsubmit="return validateForm()" >
    <h2>Registration Form</h2>
    <div class="box">
        <label>Full Name</label>
        <input type="text" name="name" id="name" placeholder="Full name">
        <div class="error" id="nameErr"></div>
    </div>
    <div class="box">
        <label>Email Address</label>
        <input type="text" name="email" id="email" placeholder="Email address">
        <div class="error" id="emailErr"></div>
    </div>
    <div class="box">
        <label>Mobile Number</label>
        <input type="text" name="mobile" maxlength="11" id="mobile" placeholder="Mobile number">
        <div class="error" id="mobileErr"></div>
    </div>
    <div class="box">
        <label>Country</label>
        <select name="country" id="country">
            <option>Select</option>
            <option>Bangladesh</option>
            <option>India</option>
            <option>America</option>
        </select> 
        <div class="error" id="countryErr"></div>
    </div>
    <div class="box">
        <label>Gender</label>
        <div class="form-inline" id="gender">
            <label><input type="radio" name="gender" value="male"> Male</label>
            <label><input type="radio" name="gender" value="female"> Female</label> 
        </div>
        <div class="error" id="genderErr"></div>
    </div>
          
    <div class="box">
        <input type="submit" value="Submit">
    </div>
</form>
<script>
function printError(Id, Msg) {
    document.getElementById(Id).innerHTML = Msg;
}

function validateForm() {

    var name = document.Form.name.value;
    var email = document.Form.email.value;
    var mobile = document.Form.mobile.value;
    var country = document.Form.country.value;
    var gender = document.Form.gender.value;
    

    var nameErr = emailErr = mobileErr = countryErr = genderErr = true;
    

    if(name == "") {
        printError("nameErr", "Please enter your name");
        var elem = document.getElementById("name");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
    } else {
        var regex = /^[a-zA-Z\s]+$/;                
        if(regex.test(name) === false) {
            printError("nameErr", "Please enter a valid name");
            var elem = document.getElementById("name");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
        } else {
            printError("nameErr", "");
            nameErr = false;
            var elem = document.getElementById("name");
            elem.classList.add("input-1");
            elem.classList.remove("input-2");

            
        }
    }
    

    if(email == "") {
        printError("emailErr", "Please enter your email address");
         var elem = document.getElementById("email");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
    } else {
        
        var regex = /^\S+@\S+\.\S+$/;
        if(regex.test(email) === false) {
            printError("emailErr", "Please enter a valid email address");
            var elem = document.getElementById("email");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
        } else{
            printError("emailErr", "");
            emailErr = false;
             var elem = document.getElementById("email");
            elem.classList.add("input-1");
            elem.classList.remove("input-2");

        }
    }
    
 
    if(mobile == "") {
        printError("mobileErr", "Please enter your mobile number");
        var elem = document.getElementById("mobile");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
    } else {
        var regex = /^[0-9]\d{10}$/;
        if(regex.test(mobile) === false) {
            printError("mobileErr", "Please enter a valid mobile number");
            var elem = document.getElementById("mobile");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
        } else{
            printError("mobileErr", "");
            mobileErr = false;
            var elem = document.getElementById("mobile");
            elem.classList.add("input-1");
            elem.classList.remove("input-2");
        }
    }
    

    if(country == "Select") {
        printError("countryErr", "Please select your country");
        var elem = document.getElementById("country");
            elem.classList.add("input-4");
            elem.classList.remove("input-3");
    } else {
        printError("countryErr", "");
        countryErr = false;
        var elem = document.getElementById("country");
            elem.classList.add("input-3");
            elem.classList.remove("input-4");
    }
    

    if(gender == "") {
        printError("genderErr", "Please select your gender");
        var elem = document.getElementById("gender");
            elem.classList.add("input-4");
            elem.classList.remove("input-3");
    } else {
        printError("genderErr", "");
        genderErr = false;
        var elem = document.getElementById("gender");
            elem.classList.add("input-3");
            elem.classList.remove("input-4");
    }
    
    
    if((nameErr || emailErr || mobileErr || countryErr || genderErr) == true) {
       return false;
    } 
};

</script>
</body>
</html>
