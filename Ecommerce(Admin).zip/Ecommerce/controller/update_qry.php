<style>
body{

    background:#6c89;
    background-position: center;
    background-repeat: no-repeat;
    background-size:100%;
    font-family: 'Roboto', sans-serif;
    font-style:italic;
}
</style>
<?php
require_once "connect.php";

if(isset($_POST["submit"])){
	$id = $_POST['id'];
	$name = $_POST['name'];
	$price = $_POST['price'];
	$qty = $_POST['qty'];
	$model = $_POST['model'];
	$brand = $_POST['brand'];
	$des = $_POST['des'];
	$date=(date("Y-m-d",time()));
	$m_cat = $_POST['m_cat'];
   

		$insert = $conn->query("REPLACE into i_new_product VALUES ($id,'$name',$price,$qty,'$model','$brand','$des','$date', $m_cat)");
       



	   if($insert){
            echo "File uploaded successfully.";
        }else{
            echo "File upload failed, please try again.";
        } 
    
}

header('Location: up_all.php');
?>