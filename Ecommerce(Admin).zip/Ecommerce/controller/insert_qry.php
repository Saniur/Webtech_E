<style>
body{

    background:#6c89;
    background-position: center;
    background-repeat: no-repeat;
    background-size:100%;
    font-family: 'Roboto', sans-serif;
    font-style:italic;
}
</style>
<?php
require_once "connect.php";

if(isset($_POST["submit"])){
	$id = $_POST['id'];
	$name = $_POST['name'];
	$price = $_POST['price'];
	$qty = $_POST['qty'];
	$model = $_POST['model'];
	$brand = $_POST['brand'];
	//$cat = $_POST['cat'];
	//$m_cat = $_POST['m_cat'];
	$des = $_POST['des'];
	$date=(date("Y-m-d",time()));
	$m_cat = $_POST['m_cat'];
		
		
		

		$insert = $conn->query("INSERT into i_new_product VALUES ($id,'$name', $price , $qty , '$model' , $brand ,'$des', '$date', $m_cat)");
        if($insert){
            echo "File uploaded successfully.";
		if($conn->connect_error)
		{
	       die("Connection failed:".$conn->connect_error);
        }
        else
        {
		    $q="SELECT * from i_new_product";
	        $result=$conn->query($q);
	        $output='<table border="1" width=100%><tr><th>Product ID</th><th>Name</th><th>Price</th><th>Quantity</th><th>Model</th><th>Brand</th><th>Full Description</th><th>Date</th><th>Main Category</th></tr>';
	        if($result->num_rows>0)
	        {
		      while($row=$result->fetch_assoc())
		      {
			     $output.= "<tr><td>{$row["id"]}</td><td>{$row["name"]}</td><td>{$row["price"]}</td><td>{$row["qty"]}</td><td>{$row["model"]}</td><td>{$row["brand"]}</td><td>{$row["des"]}</td><td>{$row["date"]}</td><td>{$row["m_cat"]}</td></tr>";
		      }
		      $output.='</table>';
	        }
	        else
		      echo "O results";
		}
		$conn->close();
	    echo $output;
		
        }else{
            echo "File upload failed, please try again.";
        } 
 //   }else{
 //       echo "Please select an image file to upload.";
 //   }
}
 echo '<META HTTP-EQUIV=REFRESH CONTENT="; insert.php">' ;

?>

