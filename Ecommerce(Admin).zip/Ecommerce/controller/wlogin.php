<?php
include "connect.php";


session_start();
	if(isset($_SESSION['u_name'])){	
	
	echo '
			<script type = "text/javascript">
				alert("ALREADY LOGED-IN");
				window.location = "index.php";
			</script>
		';
} else {
	require_once "header.php";
?>
<!--header//-->
<style>
body{

    background:#9b59;
    background-position: center;
    background-repeat: no-repeat;
    background-size:100%;
    font-family: 'Roboto', sans-serif;
    font-style:italic;
}
</style>
<head>

<script>
function showResult(str) {
  if (str.length==0) { 
    document.getElementById("livesearch").innerHTML="";
    document.getElementById("livesearch").style.border="0px";
    return;
  }
  if (window.XMLHttpRequest) {
    
    xmlhttp=new XMLHttpRequest();
  } else {  // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("livesearch").innerHTML=this.responseText;
      document.getElementById("livesearch").style.border="0px solid #A5ACB2";
    }
  }
  xmlhttp.open("GET","validation.php?u_name="+str,true);
	xmlhttp.open("GET","validation.php?password="+str,true);
  xmlhttp.send();
  xmlhttp.send();
}

</script>


</head>

<div class="login">
	 <div class="container">
			<ol class="breadcrumb">
		  <li><a href="index.html">Home</a></li>
		  <li class="active">Login</li>
		 </ol>
		 <h2>Login</h2>
		 <div class="col-md-6 log">			 
				 <p>Welcome, please enter the following details to continue.</p>
				 <form action="validation.php" method="post">
					 <h5>User Name:</h5>	
					 <input type="text" value="" name="u_name"required="" placeholder="User name">
					  <div id="livesearch"></div>
					  <h5>Password:</h5>
					 <input type="password" value="" name="password"required=""  placeholder="Password">					
					  <div id="password"></div><br>
					  <input type="checkbox" name="remember" value="1"><span style='color:blue'>&nbsp;Remember Me <br><br>
					 <input type="submit" value="Login" onkeyup="showResult(this.value)">
					  <div id="livesearch"></div>
					  User Name or Password is Incorrect !!!
				 </form>				 
		 </div>
		  <div class="col-md-6 login-right">
			  	<h3>NEW REGISTRATION</h3>
				<p>Are you new Admin? Create an Account first..</p>
				<a class="acount-btn" href="registration.php">Create an Account</a>
		 </div>
		 <div class="clearfix"></div>		 
		 
	 </div>
</div>
<!--fotter-->
<?php
 require_once "footer.php";
}
?>
<!--fotter//-->	
</body>
</html>	