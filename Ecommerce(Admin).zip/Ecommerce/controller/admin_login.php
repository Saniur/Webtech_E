<?php
include "connect.php";


session_start();
	if(isset($_SESSION['admin_name'])){	
	
	echo '
			<script type = "text/javascript">
				alert("ALREADY LOGED-IN");
				window.location = "admin.php";
			</script>
		';
} else {
	require_once "header.php";
?>
<!--header//-->
<style>
body{

    background:#9b59;
    background-position: center;
    background-repeat: no-repeat;
    background-size:100%;
    font-family: 'Roboto', sans-serif;
    font-style:italic;
}
</style>

<div class="login">
	 <div class="container">
			<ol class="breadcrumb">
		  <li><a href="admin.php">Home</a></li>
		  <li class="active">Admin Login</li>
		 </ol>
		 <h2>Admin Login</h2>
		 <div class="col-md-6 log">			 
				 <p>Welcome, please enter the following details to continue.</p>
				 <form action="validation.php" method="POST">
					 <h5>User Name:</h5>	
					 <input type="text" value="" name="admin_name" required="" placeholder=" User name">
					 <h5>Password:</h5>
					 <input type="password" value="" name="password" required="" placeholder="Password" ><br>
                     <input type="checkbox" name="remember" value="1"><span style='color:blue'>&nbsp;Remember Me <br><br>					 
					 <input type="submit" value="Login">
					  
				 </form>				 
		 </div>
		 <div class="col-md-6 login-right">
			  	<h3>NEW REGISTRATION</h3>
				<p>Are you new Admin? Create an Account first..</p>
				<a class="acount-btn" href="registration.php">Create an Account</a>
		 </div>
		 
		 <div class="clearfix"></div>		 
		 
	 </div>
</div>
<!--fotter-->
<?php
require_once "footer.php";

?>
<!--fotter//-->	
</body>
</html>

<?php

 }
?>
		