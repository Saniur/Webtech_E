<?php

session_start();
require_once "connect.php";

?>

<!DOCTYPE html>


<head>
<title>Online Ecommerce Shopping</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href='http://fonts.googleapis.com/css?family=Raleway:400,200,600,800,700,500,300,100,900' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Arimo:400,700,700italic' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="css/component.css" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" >
<meta name="keywords" content="DAP Fashions, Bootstrap Web Templates, Flat Web, Andriod, 
Smartphone Compatible, web designs for Women and men clothing and fashion web design" 
		/>
		
<script src="js/jquery.min.js"></script>
<script src="js/simpleCart.min.js"> </script>
<!-- start menu -->
<link href="css/megamenu.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="js/megamenu.js"></script>
<script>$(document).ready(function(){$(".megamenu").megamenu();});</script>
<!-- start menu -->


</head>
<body>



	<div class="login">
		<div class="container">
					<ol class="breadcrumb">
						<li>Opps!!!</li>
					</ol>
				 
				 <div class="col-md-12 log">			 
						 <p>
						     
							 <h3> Opps...!! </h3>
						    <h1>404</h1>
						     <p>Something went wrong. </p>
						 </p>
										 
				 </div>
				 
				 <div class="clearfix"></div>		 
		 
		</div>
	</div>

<!--.....footer.....-->

<?php
require_once "men_footer.php";

?>

<!..../footr....-->
</body>

</html>