

<!--fotter-->
<div class="fotter-logo">
	 <div class="container">
	 <div class="ftr-logo"><h3><a href="index.php">Online Ecommerce Shopping</a></h3></div>
	 <div class="ftr-info">
	 <p>&copy; 2021 All Rights Reseverd Design by <i>Online Ecommerce Shopping</i> </p>
	</div>
	 <div class="clearfix"></div>
	 </div>
</div>
<!--fotter//-->

</body>