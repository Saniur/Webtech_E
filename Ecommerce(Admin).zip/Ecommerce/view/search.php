
<html>
<?php
	session_start();
		if(isset($_SESSION['admin_name'])){	
		$admin_name= $_SESSION['admin_name'] ;	
		require_once "connect.php";
		require_once "header.php";
		require_once "admin_head.php";
?>

<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>Select</title>
		<link rel="stylesheet" href="../css/style.css?v=<?php echo time(); ?>">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
		<script src="https://use.fontawesome.com/0f09624171.js"></script>
	</head>
	<body>
	   		
			<div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
				<ol class="breadcrumb">
				  <li><a href="admin.php">Dashboard</a></li>
				  <li class="active">View</li>
				 </ol>
                    
                </div>

					<span class="input-group-addon"><i class="fa fa-search"></i> Search</span>

					<input type="text" name="search_text" id="search_text" placeholder="" class="form-control" />
					
				</div>
			</div>
			<br />
			<div id="result"></div>
		</div>
		<div style="clear:both"></div>
		<br />
		
		<br />
		<br />
		<br />
<h2>Data will be loaded in ajax from the database</h2>
	<button id="load">Click!</button>    
	<div id="main">
	</div>
	<script src="jquery.js"></script>
	<script>
		$(document).ready(function(){
			$("#load").on("click",function(e){
				$.ajax({
					url:"second.php",
					type:"POST",
					success:function(data){
						$("#main").html(data);
					}
				});
			});
		});
	</script>
	</body>
</html>

<?php


		} else {
				
				echo'
			<script type = "text/javascript">
				alert("Sign In First!!!");
				window.location = "admin_login.php";
			</script>
		';
		}
?>
</body>
</html>